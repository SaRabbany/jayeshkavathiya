import React from 'react';
import '../Allcss/Rodemap2.css';

const Roadmap2 = () => {
    return (
      <div className="roadmap2_area">
        <div className="container">
          <h2 className="roadmap2_title" data-aos="fade-up">
            OVERALL VISION
          </h2>

          <p className="roadmap2_text" data-aos="fade-up">
            Our long-term goal is to form a DAO which will contribute toward helping/funding various projects related to dimate change and endangered species. Also, we plan to launch more endangered
            species projects and would like to create a meta verse that we can continue to build with each project where all the endangered animals can live and interact together We also want to
            create our own token and DAO with the token having utility within the metaverse we create and would also give voting pover within the DAO
          </p>
        </div>
      </div>
    );
};

export default Roadmap2;